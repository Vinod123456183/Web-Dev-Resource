import { Work_Sans } from "next/font/google";

const workSans = Work_Sans({
  subsets: ["latin"],
});

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <div className={workSans.className}>{children}</div>;
    </>
  );
}

import React from 'react'

function page() {
  return (
    <div>
      inside admin page
    </div>
  )
}

export default page

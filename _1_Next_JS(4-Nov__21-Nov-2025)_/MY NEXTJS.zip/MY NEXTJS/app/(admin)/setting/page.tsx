import Image from "next/image";

function Page() {
  return (
    <div className="flex justify-center items-center min-h-screen  ">
      <div className="relative w-80 h-80">
        <Image
          src="/asas.jpg" // make sure this file exists in /public
          alt="File icon"
          fill
          quality={100}
          placeholder="blur"
          // blurDataURL="https://imgs.search.brave.com/A4JOsqbFb1AtvcW_QnemraCf3j28Xt3EdoLBCoRZBno/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWcu/ZnJlZXBpay5jb20v/cHJlbWl1bS1waG90/by9vY2Vhbi1ibHVy/LWJhY2tncm91bmQt/YWJzdHJhY3Qtc3Vu/cmlzZS1za3ktb2Nl/YW4tbmF0dXJlLWJh/Y2tncm91bmRfNTU4/ODczLTI0OTguanBn/P3NlbXQ9YWlzX2h5/YnJpZCZ3PTc0MCZx/PTgw" // 👈 small blurred version
          blurDataURL="/asas.jpg" // 👈 small blurred version
        />
      </div>
    </div>
  );
}

export default Page;

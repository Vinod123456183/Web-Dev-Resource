import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Get Touch in User Page : User Page",
  description: "Learn more about Thapa Technical’s mission and team.",
  openGraph: {
    title: "About Thapa Technical",
    description: "Discover who we are and what we do.",
    images: ["/about-og.png"],
  },
};

export default function AboutPage() {
  return <h1>user-- Thapa Technical</h1>;
}

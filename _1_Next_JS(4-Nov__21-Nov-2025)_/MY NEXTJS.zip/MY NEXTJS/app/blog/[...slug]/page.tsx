const Blog = async(props) =>{
    const {slug} = await props.params;
    console.log("Slug Values - ",slug);
    return(
        <div>
            {/* http://localhost:3000/blog/techononly/frontend/backend/database */}
            <h1>Blog Page</h1>
        </div>
    )
}

export default Blog;
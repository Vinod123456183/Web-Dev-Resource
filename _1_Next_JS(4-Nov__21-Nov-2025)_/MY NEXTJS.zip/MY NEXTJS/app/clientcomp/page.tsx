"use client";

// if useclient k code ka component <.../> fir wahan usme humne use client nahi likha toh 
// it will work bec use clinet is written here.



import { useEffect, useState } from "react";

// Define a type for the post
interface Post {
  userId: number;
  id: number;
  title: string;
  body: string;
}

const URL = "https://jsonplaceholder.typicode.com/posts";

export default function Page() {
  const [posts, setPosts] = useState<Post[]>([]); // use Post[] type

  // Fetch posts from the API
  async function fetchData() {
    try {
      const res = await fetch(URL);
      if (!res.ok) throw new Error("Failed to fetch posts");
      const data: Post[] = await res.json(); // type the fetched data
      console.log("Fetched Posts:", data);
      setPosts(data);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <main className="w-full min-h-screen flex flex-col items-center justify-center p-8">
      <button
        onClick={() => alert("Hii")}
        className="cursor-pointer bg-amber-800 text-white w-80 p-4 rounded mb-6"
      >
        Press Me
      </button>

      <h1 className="text-2xl font-bold mb-4">Posts from API:</h1>
      <div className="w-full max-w-2xl shadow p-4 rounded">
        {posts.length > 0 ? (
          <ul className="space-y-2">
            {posts.slice(0, 12).map((post) => (
              <li key={post.id} className="border-b pb-2">
                <h2 className="font-semibold">{post.title}</h2>
                <p className="text-gray-600">{post.body}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500 text-center">Loading posts...</p>
        )}
      </div>
    </main>
  );
}

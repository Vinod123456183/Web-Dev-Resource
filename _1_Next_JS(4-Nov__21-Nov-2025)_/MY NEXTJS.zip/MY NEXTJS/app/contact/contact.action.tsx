"use server";

import { db } from "@/config/db";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export default async function ContactAction(
  prevState: any,
  formData: FormData
) {
  const form = Object.fromEntries(formData.entries()) as Record<string, string>;

  const name = form.name?.trim() || "";
  const email = form.email?.trim() || "";
  const message = form.message?.trim() || "";

  if (!name || !email || !message) {
    console.log("❌ Missing fields:", { name, email, message });

    return { success: false, error: "All fields are required" };
  }

  // 👉 THIS IS THE LOG YOU ASKED FOR
  //   console.log("✅ Message received:", {
  //     name,
  //     email,
  //     message,
  //   });

  redirect("/");

  // If you want to insert later, uncomment this

  await db.execute(
    "INSERT INTO my_table (name, email, message) VALUES (?, ?, ?)",
    [name, email, message]
  );
  revalidatePath("/dynamic");
  return { success: true };
}

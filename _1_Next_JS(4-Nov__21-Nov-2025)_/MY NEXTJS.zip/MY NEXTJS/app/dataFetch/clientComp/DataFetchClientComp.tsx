"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

interface GenderizeData {
  name: string;
  gender: string | null;
  probability: number;
  count: number;
}

const DataFetchClientComp = () => {
  const [data, setData] = useState<GenderizeData | null>(null);
  const [loading, setLoading] = useState(true);

  const searchParams = useSearchParams();
  const name = searchParams.get("name");

  useEffect(() => {
    if (!name) return;

    // we cannot use async directly in use client but
    // we can define an async function inside useEffect
    const fetchData = async () => {
      setLoading(true);
      try {
        const res = await fetch(`https://api.genderize.io?name=${name}`);
        const result = await res.json();
        setData(result);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [name]);

  // Guard to prevent SSR mismatch
  // Loading / no name guard
  if (!name || loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        {!name ? (
          <p className="text-gray-700 text-lg">No Name Provided</p>
        ) : (
          <div className="flex flex-col items-center">
            {/* Spinner */}
            <div className="w-12 h-12 border-4 border-blue-500 border-dashed rounded-full animate-spin mb-4"></div>
            <p className="text-gray-700 text-lg">Loading...</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="bg-blue- rounded-2xl shadow-2xl p-8 max-w-sm w-full text-center">
        <h1 className="text-2xl font-bold mb-4">Hello, {data?.name}!</h1>
        <p className="text-gray-600">
          Predicted Gender: {data?.gender ?? "Unknown"}
        </p>
        <p className="text-gray-400 text-sm">
          Probability: {data?.probability} | Count: {data?.count}
        </p>
        <p className="text-gray-400 text-sm">
          Percentage: {data ? (data.probability * 100).toFixed(2) : "0"}%
        </p>
      </div>
    </div>
  );
};

export default DataFetchClientComp;

const DataFetchServer = async() =>{
    const res = await fetch('https://api.genderize.io?name=lucy');
    const data = await res.json();
    console.log("Data Fetch Server Side - ", data);
    return (
        <div>
            <h1>Data {data.name}</h1>
        </div>
    )
}

export default DataFetchServer;
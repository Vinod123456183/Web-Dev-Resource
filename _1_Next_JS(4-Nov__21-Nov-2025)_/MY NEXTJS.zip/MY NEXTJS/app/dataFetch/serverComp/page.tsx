
interface DataFetchServer {
  searchParams?: { [key: string]: string | string[] | undefined };
}
const DataFetchServer = async({searchParams}: DataFetchServer) =>{
    const val = await searchParams;
    const name = val?.name;

    const res = await fetch(`https://api.genderize.io?name=${name}`);
    const data = await res.json();
    console.log("Data Fetch Server Side - ", data);



    if (!name || name.length === 0) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            No Name Provided
          </h1>
          <p className="text-gray-600">
            Please add <code>?name=yourname</code> to the URL
          </p>
        </div>
      </div>
    </div>
  );
}



    return (
        <div>
            <h1>Data {data.name}</h1>
            <h1>Data {name}</h1>
        </div>
    )
}

export default DataFetchServer;
import type { Metadata } from "next";
import { Geist, Geist_Mono, Roboto, Work_Sans } from "next/font/google";
import "./globals.css";
import Nav from "@/components/Nav";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const roboto = Roboto({
  variable: "--font-roboto",
  subsets: ["latin"],
});

const workSans = Work_Sans({
  variable: "--font-work-sans",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://thapatechnical.com"),
  title: {
    default: "Thapa Technical | Learn Web Development",
    template: "%s",
  },
  description:
    "Free tutorials on React.js, Next.js, and web development by Thapa Technical. Learn modern frontend technologies step by step.",
  keywords: [
    "Thapa Technical",
    "React",
    "Next.js",
    "Web Development",
    "Frontend Development",
    "JavaScript",
    "TypeScript",
    "HTML",
    "CSS",
    "Tailwind CSS",
    "Node.js",
    "Express",
    "MongoDB",
    "MERN Stack",
    "React Hooks",
    "Next.js App Router",
    "SEO for Next.js",
    "Learn Coding",
    "Web Development Tutorials",
    "Thapa Technical React Course",
  ],
  icons: {
    icon: "/images/kody.png",
  },
  openGraph: {
    title: "Thapa Technical",
    description: "Join the best web dev tutorials and learn React, Next.js, and more!",
    url: "https://thapatechnical.com",
    siteName: "Thapa Technical",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Thapa Technical Logo",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Thapa Technical",
    description: "Learn Web Development from scratch with Thapa Technical!",
    creator: "@thapatechnical",
    images: ["/og-image.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${roboto.variable} ${workSans.variable} antialiased`}
      >
        <Nav />
        {children}
      </body>
    </html>
  );
}

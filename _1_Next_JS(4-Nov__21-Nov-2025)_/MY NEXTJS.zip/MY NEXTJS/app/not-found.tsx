import React from 'react'

function Page() {
  return (
    <div>
     not found 
    </div>
  )
}

export default Page

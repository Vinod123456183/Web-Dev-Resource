import style from "./hist.module.css";

function hist() {
  // Classname is converted forcefully here for avoid conficts
  return <div className={style.common_color}>hist</div>;
}

export default hist;

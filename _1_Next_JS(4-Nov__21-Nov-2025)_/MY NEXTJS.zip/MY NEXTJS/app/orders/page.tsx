import React from 'react'

function page() {
  return (
    <div className='font-work'>
      inside orders page
    </div>
  )
}

export default page

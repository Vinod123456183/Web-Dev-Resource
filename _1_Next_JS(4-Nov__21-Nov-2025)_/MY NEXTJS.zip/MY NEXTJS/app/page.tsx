const Page =() =>{
  return (
    <>
    <h1>Hlo</h1>
    </>
  )
}
export default Page
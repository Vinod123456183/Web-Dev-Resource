"use client"
import { useSearchParams } from "next/navigation"

function ProductList() {
  const SearchParamss = useSearchParams();
  console.log("Inside UseSearchParams - ",SearchParamss)
  console.log("Inside--  - ",SearchParamss.get("category") , SearchParamss.get("ram") , SearchParamss.get("sort"))
  return (
    <div>
      <p>Hlo</p>
      <p>{SearchParamss.get("category")}</p>
      {/* <p>{SearchParamss.get("sort")}</p> */}
      {/* <p>{SearchParamss.get("ram")}</p> */}
    </div>
  )
}

export default ProductList

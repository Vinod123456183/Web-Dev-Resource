import ProductList from "./ProductList";

// app/products/page.tsx
interface ProductsProps {
  searchParams?: { [key: string]: string | string[] | undefined };
}

export default async function Products({ searchParams }: ProductsProps) {
  const res =  await searchParams;
const category = res?.category || 'all';
const ram = res?.ram || 'all';
const sorting = res?.sort || 'default'; 
  console.log(res);
  return (
    <div>
        <p>
             Products Page
            </p>
        <h1>
            {category}        </h1>
        <h1>
            {ram}        </h1>
        <h1>
            {sorting}        </h1>

            <ProductList/>
    </div>
  );
}

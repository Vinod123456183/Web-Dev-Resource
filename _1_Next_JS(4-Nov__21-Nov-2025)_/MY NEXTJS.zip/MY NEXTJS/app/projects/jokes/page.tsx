// app/jokes/page.tsx
import Link from "next/link";

export default async function Jokes() {
  // Server-side fetch — always runs fresh
  const res = await fetch("https://official-joke-api.appspot.com/random_joke", {
    cache: "no-store",
  });
  const joke = await res.json();

  console.log("Joke Page - ", joke);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-indigo-50 to-blue-100 p-6">
      <div className="bg-white shadow-2xl rounded-2xl p-8 max-w-md w-full text-center">
        <h1 className="text-3xl font-bold text-blue-600 mb-4">😂 Jokes Page</h1>
        <p className="text-gray-700 text-lg mb-4">{joke.setup}</p>

        <p className="text-green-600 font-semibold text-xl mb-8">
          {joke.punchline}
        </p>

        {/* Refresh link to load a new joke */}
        <Link
          href="/"
          className="inline-block px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg shadow-md transition"
        >
          Get Another Joke
        </Link>
      </div>
    </div>
  );
}

import { db } from "@/config/db";
import { cache } from "react";

export const revalidate = 10; // page re-caches every 10 seconds

export const getAllDoctors = cache(async () => {
  console.log("Fetching doctors from DB...");
  const [doctors] = await db.execute("SELECT * FROM doctors");
  return doctors;
});

const Page = async () => {
  try {
    const doctors = await getAllDoctors();

    return (
      <div>
        <h1>Doctors List</h1>
        <ul>
          {doctors.map((doctor) => (
            <li key={doctor.doctor_id}>
              {doctor.first_name} {doctor.last_name} - {doctor.specialization}
            </li>
          ))}
        </ul>
      </div>
    );
  } catch (err) {
    console.error("Error fetching doctors:", err);
    return <p>Failed to load doctors.</p>;
  }
};

export default Page;

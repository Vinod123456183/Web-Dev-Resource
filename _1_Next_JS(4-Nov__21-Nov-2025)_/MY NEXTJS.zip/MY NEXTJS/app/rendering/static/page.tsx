// In dynamic route changes are  seen in the main after refresh

import { db } from "@/config/db";

// ISR - Incremental Static Regeneration
export const revalidate = 60;

const Page = async () => {
  try {
    const [doctors] = await db.execute("SELECT * FROM doctors");
    console.log(doctors);

    return (
      <div>
        <h1>Doctors List</h1>
        <ul>
          {doctors.map((doctor) => (
            <li key={doctor.doctor_id}>
              {doctor.first_name} {doctor.last_name} - {doctor.specialization}
            </li>
          ))}
        </ul>
      </div>
    );
  } catch (err) {
    console.error("Error fetching doctors:", err);
    return <p>Failed to load doctors.</p>;
  }
};

export default Page;

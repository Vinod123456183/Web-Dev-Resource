const URL = "https://jsonplaceholder.typicode.com/posts";

interface Post {
  userId: number;
  id: number;
  title: string;
  body: string;
}
 
async function fetchPosts(): Promise<Post[]> {
  const res = await fetch(URL);
  if (!res.ok) {
    throw new Error("Failed to fetch posts");
  }
  const data: Post[] = await res.json();
  return data;
}

const Page = async () => {
  const posts = await fetchPosts(); // fetch data on the server

  return (
    <div className="p-8">
      <p>Server Component Page</p>
      <h1 className="text-2xl font-bold my-4">Posts from API:</h1>
      <div className="space-y-4">
        {posts.slice(0, 12).map((post) => (
          <div key={post.id} className="border p-4 rounded shadow">
            <h2 className="font-semibold">{post.title}</h2>
            <p className="text-gray-600">{post.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Page;

"use client";

import { Suspense } from "react";
import DataFetchClientComp from "../dataFetch/clientComp/DataFetchClientComp";

const DataFetchServer = () => {
  return (
    <div className="grid grid-cols-2">
      <div>
        <p>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Soluta dicta
          optio in exercitationem, at totam quibusdam. Adipisci rerum atque
          quidem?
        </p>
      </div>
      <div>
        <Suspense
          fallback={
            <div className="bg-red-700">Loading Client Component...</div>
          }
        >
          <DataFetchClientComp />
        </Suspense>
      </div>
    </div>
  );
};

export default DataFetchServer;

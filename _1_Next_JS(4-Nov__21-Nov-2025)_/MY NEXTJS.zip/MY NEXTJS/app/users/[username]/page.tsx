import React from "react";

interface PageProps {
  params: Promise<{
    username: string;
  }>;
}

export default async function Page({ params }: PageProps) {
  // ✅ unwrap the React Promise
  const resolvedParams = await params;

  const username = resolvedParams?.username;

  return (
    <div>
      <h1>Single Profile Page:</h1>
      {username ? <p>Username: {username}</p> : <p>No username provided</p>}
    </div>
  );
}

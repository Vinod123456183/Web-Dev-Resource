'use client';

import React, { use } from 'react';

interface PageProps {
  params: Promise<{ username: string }>;
}

export default function Page({ params }: PageProps) {
  const resolvedParams = use(params); // unwrap the promise
  const { username } = resolvedParams;

  return (
    <div>
      <h1>Single Profile Page:</h1>
      {username ? <p>Username: {username}</p> : <p>No username provided</p>}
    </div>
  );
}








// -----------------SERVER Component--------------

// // Dynamic route will always work on the server conponents

// interface PageProps {
//   params: Promise<{
//     postId: string;
//     username: string;
//   }>;
// }

// export default async function Page({ params }: PageProps) {
//   // ✅ unwrap the React Promise
//   const res = await params;

//   const postId = res?.postId;
//   const username = res?.username;

//   return (
//     <div>
//       <h1>Single Profile Page:</h1>
//       {postId ? < p>postId: {postId}</p> : <p>No postId provided</p>}
//       {username ? < p>username: {username}</p> : <p>No username provided</p>}
//     </div>
//   );
// }

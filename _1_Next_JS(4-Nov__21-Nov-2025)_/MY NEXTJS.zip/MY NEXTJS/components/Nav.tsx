// app/components/Nav.tsx
import Link from "next/link";
import { FC } from "react";

const Nav: FC = () => {
  return (
    <nav>
      <ul>
        <li><Link href="/">Nav</Link></li>
      </ul>
    </nav>
  );
};

export default Nav;

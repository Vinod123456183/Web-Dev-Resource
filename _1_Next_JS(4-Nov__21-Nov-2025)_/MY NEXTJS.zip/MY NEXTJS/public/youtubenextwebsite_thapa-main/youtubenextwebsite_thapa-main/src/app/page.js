import Herosection from "@/app/components/Herosection";

const Page = () => {
    return (
        <>
          <Herosection title={"LET\'S WATCH MOVIE TOGETHER"} imageUrl={"/home.svg"} />
        </>
    );
};

export default Page;